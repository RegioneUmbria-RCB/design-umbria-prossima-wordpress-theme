!(function (e) {
  var t = {};
  function n(r) {
    if (t[r]) return t[r].exports;
    var i = (t[r] = {
      i: r,
      l: !1,
      exports: {},
    });
    return e[r].call(i.exports, i, i.exports, n), (i.l = !0), i.exports;
  }
  (n.m = e),
    (n.c = t),
    (n.d = function (e, t, r) {
      n.o(e, t) ||
        Object.defineProperty(e, t, {
          enumerable: !0,
          get: r,
        });
    }),
    (n.r = function (e) {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, {
          value: "Module",
        }),
        Object.defineProperty(e, "__esModule", {
          value: !0,
        });
    }),
    (n.t = function (e, t) {
      if ((1 & t && (e = n(e)), 8 & t)) return e;
      if (4 & t && "object" == typeof e && e && e.__esModule) return e;
      var r = Object.create(null);
      if (
        (n.r(r),
        Object.defineProperty(r, "default", {
          enumerable: !0,
          value: e,
        }),
        2 & t && "string" != typeof e)
      )
        for (var i in e)
          n.d(
            r,
            i,
            function (t) {
              return e[t];
            }.bind(null, i)
          );
      return r;
    }),
    (n.n = function (e) {
      var t =
        e && e.__esModule
          ? function () {
              return e.default;
            }
          : function () {
              return e;
            };
      return n.d(t, "a", t), t;
    }),
    (n.o = function (e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }),
    (n.p = ""),
    n((n.s = 0));
})([
  function (e, t, n) {
    n(7), (e.exports = n(6));
  },
  function (e, t) {
    var n = document.querySelector(".cmp-rating"),
      r = 0;
    function i() {
      var e = n.querySelector(".form-rating");
      e.classList.remove("d-none");
      var t = document.querySelector('[name="ratingA"]:checked');
      (parseInt(t.value) > 3
        ? document.querySelector(".fieldset-rating-one")
        : document.querySelector(".fieldset-rating-two")
      ).classList.remove("d-none");
      var i = n.querySelector('[data-step="'.concat(r + 1, '"]'));
      i.classList.remove("d-none"), i.classList.add("active");
      var o = n.querySelectorAll("[data-step]");
      if ((r += 1) == o.length) {
        var a = n.querySelector(".cmp-rating__card-first");
        e.classList.add("d-none"), a.classList.add("d-none");
        var u = new Event("feedback-submit");
        document.dispatchEvent(u);
      }
    }
    function o() {
      var e = document.querySelector(".fieldset-rating-one"),
        t = document.querySelector(".fieldset-rating-two");
      e.classList.add("d-none"), t.classList.add("d-none");
    }
    function a() {
      var e = n.querySelector("[data-step].active");
      e && (e.classList.add("d-none"), e.classList.remove("active"));
    }
    !(function () {
      if (n) {
        var e = n.querySelectorAll(".rating input"),
          t = n.querySelector(".btn-next"),
          u = n.querySelector(".btn-back");
        e.forEach(function (e) {
          e.addEventListener("change", function () {
            a(),
              n.querySelector(".form-rating").classList.add("d-none"),
              o(),
              (r = 0),
              e.checked && i();
          });
        }),
          t &&
            t.addEventListener("click", function () {
              a(), i();
            }),
          u &&
            u.addEventListener("click", function () {
              a(),
                (function () {
                  var e = n.querySelector(".form-rating");
                  if ((e.classList.remove("d-none"), 0 == (r -= 1))) {
                    e.classList.add("d-none"),
                      n
                        .querySelector(".cmp-rating__card-first")
                        .classList.remove("d-none"),
                      o(),
                      (document.querySelector(
                        '[name="ratingA"]:checked'
                      ).checked = !1);
                  } else {
                    var t = n.querySelector('[data-step="'.concat(r + 1, '"]'));
                    t.classList.add("d-none"), t.classList.remove("active");
                    var i = n.querySelector('[data-step="'.concat(r, '"]'));
                    i.classList.remove("d-none"), i.classList.add("active");
                  }
                })();
            });
      }
    })();
  },
  function (e, t) {
    var n = document.querySelector("#toggle-toggle"),
      r = document.querySelector(".infoWrapper");
    n &&
      n.addEventListener("change", function () {
        r.classList.toggle("d-none");
      });
  },
  function (e, t) {
    function n(e) {
      return (
        (function (e) {
          if (Array.isArray(e)) return r(e);
        })(e) ||
        (function (e) {
          if (
            ("undefined" != typeof Symbol && null != e[Symbol.iterator]) ||
            null != e["@@iterator"]
          )
            return Array.from(e);
        })(e) ||
        (function (e, t) {
          if (!e) return;
          if ("string" == typeof e) return r(e, t);
          var n = Object.prototype.toString.call(e).slice(8, -1);
          "Object" === n && e.constructor && (n = e.constructor.name);
          if ("Map" === n || "Set" === n) return Array.from(e);
          if (
            "Arguments" === n ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
          )
            return r(e, t);
        })(e) ||
        (function () {
          throw new TypeError(
            "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
          );
        })()
      );
    }
    function r(e, t) {
      (null == t || t > e.length) && (t = e.length);
      for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    var i = n(document.querySelectorAll(".radio-card"));
    n(document.querySelectorAll(".radio-input")).forEach(function (e, t) {
      e.addEventListener("change", function () {
        i.forEach(function (e, n) {
          t == n
            ? e.classList.add("has-border-green")
            : e.classList.remove("has-border-green");
        });
      });
    });
  },
  function (e, t) {
    function n(e) {
      return (
        (function (e) {
          if (Array.isArray(e)) return r(e);
        })(e) ||
        (function (e) {
          if (
            ("undefined" != typeof Symbol && null != e[Symbol.iterator]) ||
            null != e["@@iterator"]
          )
            return Array.from(e);
        })(e) ||
        (function (e, t) {
          if (!e) return;
          if ("string" == typeof e) return r(e, t);
          var n = Object.prototype.toString.call(e).slice(8, -1);
          "Object" === n && e.constructor && (n = e.constructor.name);
          if ("Map" === n || "Set" === n) return Array.from(e);
          if (
            "Arguments" === n ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
          )
            return r(e, t);
        })(e) ||
        (function () {
          throw new TypeError(
            "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
          );
        })()
      );
    }
    function r(e, t) {
      (null == t || t > e.length) && (t = e.length);
      for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    var i = n(document.querySelectorAll(".cmp-info-checkbox"));
    n(document.querySelectorAll(".check-input")).forEach(function (e, t) {
      e.addEventListener("change", function () {
        i.forEach(function (e, n) {
          t == n && e.classList.toggle("has-border-green");
        });
      });
    });
  },
  function (e, t) {
    var n = document.querySelectorAll('input[type="text"]');
    n.length &&
      n.forEach(function (e) {
        e.addEventListener("input", function () {
          if (e.value.length > 0) {
            if (!e.parentElement.querySelector(".clean-input")) {
              e.insertAdjacentHTML(
                "afterend",
                '\n          <button type="button" class="clean-input" aria-label="Elimina testo di ricerca">\n            <svg class="icon">\n              <use xlink:href="../assets/bootstrap-italia/dist/svg/sprites.svg#it-close"></use>\n            </svg>\n          </button>\n          '
              );
              var t = e.parentElement.querySelector(".clean-input"),
                n = e.parentElement.querySelector(".cmp-input__label");
              t.addEventListener("click", function () {
                (e.value = ""), t.remove(), n.classList.remove("active");
              });
            }
          } else e.parentElement.querySelector(".clean-input").remove();
        });
      });
  },
  function (e, t, n) {},
  function (e, t, n) {
    "use strict";
    function r(e, t) {
      for (var n = 0; n < t.length; n++) {
        var r = t[n];
        (r.enumerable = r.enumerable || !1),
          (r.configurable = !0),
          "value" in r && (r.writable = !0),
          Object.defineProperty(e, r.key, r);
      }
    }
    n.r(t);
    /*!
     * Splide.js
     * Version  : 4.0.17
     * License  : MIT
     * Copyright: 2022 Naotoshi Fujita
     */
    var i = {
      CREATED: 1,
      MOUNTED: 2,
      IDLE: 3,
      MOVING: 4,
      SCROLLING: 5,
      DRAGGING: 6,
      DESTROYED: 7,
    };
    function o(e) {
      e.length = 0;
    }
    function a(e, t, n) {
      return Array.prototype.slice.call(e, t, n);
    }
    function u(e) {
      return e.bind.apply(e, [null].concat(a(arguments, 1)));
    }
    var s = setTimeout,
      c = function () {};
    function l(e) {
      return requestAnimationFrame(e);
    }
    function d(e, t) {
      return typeof t === e;
    }
    function f(e) {
      return !g(e) && d("object", e);
    }
    var p = Array.isArray,
      v = u(d, "function"),
      m = u(d, "string"),
      h = u(d, "undefined");
    function g(e) {
      return null === e;
    }
    function y(e) {
      return e instanceof HTMLElement;
    }
    function b(e) {
      return p(e) ? e : [e];
    }
    function S(e, t) {
      b(e).forEach(t);
    }
    function w(e, t) {
      return e.indexOf(t) > -1;
    }
    function E(e, t) {
      return e.push.apply(e, b(t)), e;
    }
    function _(e, t, n) {
      e &&
        S(t, function (t) {
          t && e.classList[n ? "add" : "remove"](t);
        });
    }
    function L(e, t) {
      _(e, m(t) ? t.split(" ") : t, !0);
    }
    function x(e, t) {
      S(t, e.appendChild.bind(e));
    }
    function A(e, t) {
      S(e, function (e) {
        var n = (t || e).parentNode;
        n && n.insertBefore(e, t);
      });
    }
    function k(e, t) {
      return y(e) && (e.msMatchesSelector || e.matches).call(e, t);
    }
    function C(e, t) {
      var n = e ? a(e.children) : [];
      return t
        ? n.filter(function (e) {
            return k(e, t);
          })
        : n;
    }
    function M(e, t) {
      return t ? C(e, t)[0] : e.firstElementChild;
    }
    var P = Object.keys;
    function q(e, t, n) {
      if (e) {
        var r = P(e);
        r = n ? r.reverse() : r;
        for (var i = 0; i < r.length; i++) {
          var o = r[i];
          if ("__proto__" !== o && !1 === t(e[o], o)) break;
        }
      }
      return e;
    }
    function T(e) {
      return (
        a(arguments, 1).forEach(function (t) {
          q(t, function (n, r) {
            e[r] = t[r];
          });
        }),
        e
      );
    }
    function z(e) {
      return (
        a(arguments, 1).forEach(function (t) {
          q(t, function (t, n) {
            p(t)
              ? (e[n] = t.slice())
              : f(t)
              ? (e[n] = z({}, f(e[n]) ? e[n] : {}, t))
              : (e[n] = t);
          });
        }),
        e
      );
    }
    function F(e, t) {
      b(t || P(e)).forEach(function (t) {
        delete e[t];
      });
    }
    function I(e, t) {
      S(e, function (e) {
        S(t, function (t) {
          e && e.removeAttribute(t);
        });
      });
    }
    function j(e, t, n) {
      f(t)
        ? q(t, function (t, n) {
            j(e, n, t);
          })
        : S(e, function (e) {
            g(n) || "" === n ? I(e, t) : e.setAttribute(t, String(n));
          });
    }
    function O(e, t, n) {
      var r = document.createElement(e);
      return t && (m(t) ? L(r, t) : j(r, t)), n && x(n, r), r;
    }
    function D(e, t, n) {
      if (h(n)) return getComputedStyle(e)[t];
      g(n) || (e.style[t] = "" + n);
    }
    function N(e, t) {
      D(e, "display", t);
    }
    function R(e) {
      (e.setActive && e.setActive()) ||
        e.focus({
          preventScroll: !0,
        });
    }
    function H(e, t) {
      return e.getAttribute(t);
    }
    function Q(e, t) {
      return e && e.classList.contains(t);
    }
    function W(e) {
      return e.getBoundingClientRect();
    }
    function U(e) {
      S(e, function (e) {
        e && e.parentNode && e.parentNode.removeChild(e);
      });
    }
    function B(e) {
      return M(new DOMParser().parseFromString(e, "text/html").body);
    }
    function G(e, t) {
      e.preventDefault(),
        t && (e.stopPropagation(), e.stopImmediatePropagation());
    }
    function X(e, t) {
      return e && e.querySelector(t);
    }
    function V(e, t) {
      return t ? a(e.querySelectorAll(t)) : [];
    }
    function Y(e, t) {
      _(e, t, !1);
    }
    function K(e) {
      return e.timeStamp;
    }
    function $(e) {
      return m(e) ? e : e ? e + "px" : "";
    }
    function J(e, t) {
      if (!e) throw new Error("[splide] " + (t || ""));
    }
    var Z = Math.min,
      ee = Math.max,
      te = Math.floor,
      ne = Math.ceil,
      re = Math.abs;
    function ie(e, t, n) {
      return re(e - t) < n;
    }
    function oe(e, t, n, r) {
      var i = Z(t, n),
        o = ee(t, n);
      return r ? i < e && e < o : i <= e && e <= o;
    }
    function ae(e, t, n) {
      var r = Z(t, n),
        i = ee(t, n);
      return Z(ee(r, e), i);
    }
    function ue(e) {
      return +(e > 0) - +(e < 0);
    }
    function se(e, t) {
      return (
        S(t, function (t) {
          e = e.replace("%s", "" + t);
        }),
        e
      );
    }
    function ce(e) {
      return e < 10 ? "0" + e : "" + e;
    }
    var le = {};
    function de(e) {
      return "" + e + ce((le[e] = (le[e] || 0) + 1));
    }
    function fe() {
      var e = [];
      function t(e, t, n) {
        S(e, function (e) {
          e &&
            S(t, function (t) {
              t.split(" ").forEach(function (t) {
                var r = t.split(".");
                n(e, r[0], r[1]);
              });
            });
        });
      }
      return {
        bind: function (n, r, i, o) {
          t(n, r, function (t, n, r) {
            var a = "addEventListener" in t,
              u = a
                ? t.removeEventListener.bind(t, n, i, o)
                : t.removeListener.bind(t, i);
            a ? t.addEventListener(n, i, o) : t.addListener(i),
              e.push([t, n, r, i, u]);
          });
        },
        unbind: function (n, r, i) {
          t(n, r, function (t, n, r) {
            e = e.filter(function (e) {
              return (
                !!(
                  e[0] !== t ||
                  e[1] !== n ||
                  e[2] !== r ||
                  (i && e[3] !== i)
                ) || (e[4](), !1)
              );
            });
          });
        },
        dispatch: function (e, t, n) {
          var r;
          return (
            "function" == typeof CustomEvent
              ? (r = new CustomEvent(t, {
                  bubbles: !0,
                  detail: n,
                }))
              : (r = document.createEvent("CustomEvent")).initCustomEvent(
                  t,
                  !0,
                  !1,
                  n
                ),
            e.dispatchEvent(r),
            r
          );
        },
        destroy: function () {
          e.forEach(function (e) {
            e[4]();
          }),
            o(e);
        },
      };
    }
    function pe(e) {
      var t = e ? e.event.bus : document.createDocumentFragment(),
        n = fe();
      return (
        e && e.event.on("destroy", n.destroy),
        T(n, {
          bus: t,
          on: function (e, r) {
            n.bind(t, b(e).join(" "), function (e) {
              r.apply(r, p(e.detail) ? e.detail : []);
            });
          },
          off: u(n.unbind, t),
          emit: function (e) {
            n.dispatch(t, e, a(arguments, 1));
          },
        })
      );
    }
    function ve(e, t, n, r) {
      var i,
        o,
        a = Date.now,
        u = 0,
        s = !0,
        c = 0;
      function d() {
        if (!s) {
          if (
            ((u = e ? Z((a() - i) / e, 1) : 1),
            n && n(u),
            u >= 1 && (t(), (i = a()), r && ++c >= r))
          )
            return f();
          l(d);
        }
      }
      function f() {
        s = !0;
      }
      function p() {
        o && cancelAnimationFrame(o), (u = 0), (o = 0), (s = !0);
      }
      return {
        start: function (t) {
          !t && p(), (i = a() - (t ? u * e : 0)), (s = !1), l(d);
        },
        rewind: function () {
          (i = a()), (u = 0), n && n(u);
        },
        pause: f,
        cancel: p,
        set: function (t) {
          e = t;
        },
        isPaused: function () {
          return s;
        },
      };
    }
    var me = {
      width: ["height"],
      left: ["top", "right"],
      right: ["bottom", "left"],
      x: ["y"],
      X: ["Y"],
      Y: ["X"],
      ArrowLeft: ["ArrowUp", "ArrowRight"],
      ArrowRight: ["ArrowDown", "ArrowLeft"],
    };
    function he(e, t, n) {
      return {
        resolve: function (e, t, r) {
          var i =
            "rtl" !== (r = r || n.direction) || t ? ("ttb" === r ? 0 : -1) : 1;
          return (
            (me[e] && me[e][i]) ||
            e.replace(/width|left|right/i, function (e, t) {
              var n = me[e.toLowerCase()][i] || e;
              return t > 0 ? n.charAt(0).toUpperCase() + n.slice(1) : n;
            })
          );
        },
        orient: function (e) {
          return e * ("rtl" === n.direction ? 1 : -1);
        },
      };
    }
    var ge = "role",
      ye = [
        ge,
        "tabindex",
        "disabled",
        "aria-controls",
        "aria-current",
        "aria-label",
        "aria-labelledby",
        "aria-hidden",
        "aria-orientation",
        "aria-roledescription",
      ],
      be = "splide",
      Se = "is-active",
      we = [
        Se,
        "is-visible",
        "is-prev",
        "is-next",
        "is-loading",
        "is-focus-in",
      ],
      Ee = {
        slide: "splide__slide",
        clone: "splide__slide--clone",
        arrows: "splide__arrows",
        arrow: "splide__arrow",
        prev: "splide__arrow--prev",
        next: "splide__arrow--next",
        pagination: "splide__pagination",
        page: "splide__pagination__page",
        spinner: "splide__spinner",
      };
    var _e = "touchend touchcancel mouseup click";
    var Le = "loop";
    function xe(e, t, n, r) {
      var i,
        o = pe(e),
        a = o.on,
        s = o.emit,
        c = o.bind,
        l = e.Components,
        d = e.root,
        f = e.options,
        p = f.isNavigation,
        v = f.updateOnMove,
        m = f.i18n,
        h = f.pagination,
        g = f.slideFocus,
        y = l.Direction.resolve,
        b = H(r, "style"),
        S = H(r, "aria-label"),
        w = n > -1,
        E = M(r, ".splide__slide__container");
      function L() {
        var i = e.splides
          .map(function (e) {
            var n = e.splide.Components.Slides.getAt(t);
            return n ? n.slide.id : "";
          })
          .join(" ");
        j(r, "aria-label", se(m.slideX, (w ? n : t) + 1)),
          j(r, "aria-controls", i),
          j(r, ge, g ? "button" : ""),
          g && I(r, "aria-roledescription");
      }
      function x() {
        i || A();
      }
      function A() {
        if (!i) {
          var n = e.index;
          (o = k()) !== Q(r, Se) &&
            (_(r, Se, o),
            j(r, "aria-current", (p && o) || ""),
            s(o ? "active" : "inactive", C)),
            (function () {
              var t = (function () {
                  if (e.is("fade")) return k();
                  var t = W(l.Elements.track),
                    n = W(r),
                    i = y("left", !0),
                    o = y("right", !0);
                  return te(t[i]) <= ne(n[i]) && te(n[o]) <= ne(t[o]);
                })(),
                n = !t && (!k() || w);
              e.state.is([4, 5]) || j(r, "aria-hidden", n || "");
              j(V(r, f.focusableNodes || ""), "tabindex", n ? -1 : ""),
                g && j(r, "tabindex", n ? -1 : 0);
              t !== Q(r, "is-visible") &&
                (_(r, "is-visible", t), s(t ? "visible" : "hidden", C));
              if (!t && document.activeElement === r) {
                var i = l.Slides.getAt(e.index);
                i && R(i.slide);
              }
            })(),
            _(r, "is-prev", t === n - 1),
            _(r, "is-next", t === n + 1);
        }
        var o;
      }
      function k() {
        var r = e.index;
        return r === t || (f.cloneStatus && r === n);
      }
      var C = {
        index: t,
        slideIndex: n,
        slide: r,
        container: E,
        isClone: w,
        mount: function () {
          w ||
            ((r.id = d.id + "-slide" + ce(t + 1)),
            j(r, ge, h ? "tabpanel" : "group"),
            j(r, "aria-roledescription", m.slide),
            j(r, "aria-label", S || se(m.slideLabel, [t + 1, e.length]))),
            c(r, "click", u(s, "click", C)),
            c(r, "keydown", u(s, "slide:keydown", C)),
            a(["moved", "shifted", "scrolled"], A),
            a("navigation:mounted", L),
            v && a("move", x);
        },
        destroy: function () {
          (i = !0),
            o.destroy(),
            Y(r, we),
            I(r, ye),
            j(r, "style", b),
            j(r, "aria-label", S || "");
        },
        update: A,
        style: function (e, t, n) {
          D((n && E) || r, e, t);
        },
        isWithin: function (n, r) {
          var i = re(n - t);
          return (
            w || (!f.rewind && !e.is(Le)) || (i = Z(i, e.length - i)), i <= r
          );
        },
      };
      return C;
    }
    var Ae =
      "m15.5 0.932-4.3 4.38 14.5 14.6-14.5 14.5 4.3 4.4 14.6-14.6 4.4-4.3-4.4-4.4-14.6-14.6z";
    var ke = {
      passive: !1,
      capture: !0,
    };
    var Ce = {
      Spacebar: " ",
      Right: "ArrowRight",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Down: "ArrowDown",
    };
    function Me(e) {
      return (e = m(e) ? e : e.key), Ce[e] || e;
    }
    var Pe = [" ", "Enter"];
    var qe = Object.freeze({
        __proto__: null,
        Media: function (e, t, n) {
          var r = e.state,
            i = n.breakpoints || {},
            o = n.reducedMotion || {},
            a = fe(),
            u = [];
          function s(e) {
            e && a.destroy();
          }
          function c(e, t) {
            var n = matchMedia(t);
            a.bind(n, "change", l), u.push([e, n]);
          }
          function l() {
            var t = r.is(7),
              i = n.direction,
              o = u.reduce(function (e, t) {
                return z(e, t[1].matches ? t[0] : {});
              }, {});
            F(n),
              d(o),
              n.destroy
                ? e.destroy("completely" === n.destroy)
                : t
                ? (s(!0), e.mount())
                : i !== n.direction && e.refresh();
          }
          function d(t, i) {
            z(n, t),
              i && z(Object.getPrototypeOf(n), t),
              r.is(1) || e.emit("updated", n);
          }
          return {
            setup: function () {
              var e = "min" === n.mediaQuery;
              P(i)
                .sort(function (t, n) {
                  return e ? +t - +n : +n - +t;
                })
                .forEach(function (t) {
                  c(i[t], "(" + (e ? "min" : "max") + "-width:" + t + "px)");
                }),
                c(o, "(prefers-reduced-motion: reduce)"),
                l();
            },
            destroy: s,
            reduce: function (e) {
              matchMedia("(prefers-reduced-motion: reduce)").matches &&
                (e ? z(n, o) : F(n, P(o)));
            },
            set: d,
          };
        },
        Direction: he,
        Elements: function (e, t, n) {
          var r,
            i,
            a,
            u = pe(e),
            s = u.on,
            c = u.bind,
            l = e.root,
            d = n.i18n,
            f = {},
            p = [],
            m = [],
            h = [];
          function g() {
            (r = S(".splide__track")),
              (i = M(r, ".splide__list")),
              J(r && i, "A track/list element is missing."),
              E(p, C(i, ".splide__slide:not(.splide__slide--clone)")),
              q(
                {
                  arrows: "splide__arrows",
                  pagination: "splide__pagination",
                  prev: "splide__arrow--prev",
                  next: "splide__arrow--next",
                  bar: "splide__progress__bar",
                  toggle: "splide__toggle",
                },
                function (e, t) {
                  f[t] = S("." + e);
                }
              ),
              T(f, {
                root: l,
                track: r,
                list: i,
                slides: p,
              }),
              (function () {
                var e = l.id || de("splide"),
                  t = n.role;
                (l.id = e),
                  (r.id = r.id || e + "-track"),
                  (i.id = i.id || e + "-list"),
                  !H(l, ge) && "SECTION" !== l.tagName && t && j(l, ge, t);
                j(l, "aria-roledescription", d.carousel),
                  j(i, ge, "presentation");
              })(),
              b();
          }
          function y(e) {
            var t = ye.concat("style");
            o(p),
              Y(l, m),
              Y(r, h),
              I([r, i], t),
              I(l, e ? t : ["style", "aria-roledescription"]);
          }
          function b() {
            Y(l, m),
              Y(r, h),
              (m = w(be)),
              (h = w("splide__track")),
              L(l, m),
              L(r, h),
              j(l, "aria-label", n.label),
              j(l, "aria-labelledby", n.labelledby);
          }
          function S(e) {
            var t = X(l, e);
            return t &&
              (function (e, t) {
                if (v(e.closest)) return e.closest(t);
                for (var n = e; n && 1 === n.nodeType && !k(n, t); )
                  n = n.parentElement;
                return n;
              })(t, "." + be) === l
              ? t
              : void 0;
          }
          function w(e) {
            return [
              e + "--" + n.type,
              e + "--" + n.direction,
              n.drag && e + "--draggable",
              n.isNavigation && e + "--nav",
              e === be && Se,
            ];
          }
          return T(f, {
            setup: g,
            mount: function () {
              s("refresh", y),
                s("refresh", g),
                s("updated", b),
                c(
                  document,
                  "touchstart mousedown keydown",
                  function (e) {
                    a = "keydown" === e.type;
                  },
                  {
                    capture: !0,
                  }
                ),
                c(l, "focusin", function () {
                  _(l, "is-focus-in", !!a);
                });
            },
            destroy: y,
          });
        },
        Slides: function (e, t, n) {
          var r = pe(e),
            i = r.on,
            a = r.emit,
            s = r.bind,
            c = t.Elements,
            l = c.slides,
            d = c.list,
            f = [];
          function p() {
            l.forEach(function (e, t) {
              g(e, t, -1);
            });
          }
          function h() {
            _(function (e) {
              e.destroy();
            }),
              o(f);
          }
          function g(t, n, r) {
            var i = xe(e, n, r, t);
            i.mount(),
              f.push(i),
              f.sort(function (e, t) {
                return e.index - t.index;
              });
          }
          function E(e) {
            return e
              ? C(function (e) {
                  return !e.isClone;
                })
              : f;
          }
          function _(e, t) {
            E(t).forEach(e);
          }
          function C(e) {
            return f.filter(
              v(e)
                ? e
                : function (t) {
                    return m(e) ? k(t.slide, e) : w(b(e), t.index);
                  }
            );
          }
          return {
            mount: function () {
              p(), i("refresh", h), i("refresh", p);
            },
            destroy: h,
            update: function () {
              _(function (e) {
                e.update();
              });
            },
            register: g,
            get: E,
            getIn: function (e) {
              var r = t.Controller,
                i = r.toIndex(e),
                o = r.hasFocus() ? 1 : n.perPage;
              return C(function (e) {
                return oe(e.index, i, i + o - 1);
              });
            },
            getAt: function (e) {
              return C(e)[0];
            },
            add: function (e, t) {
              S(e, function (e) {
                if ((m(e) && (e = B(e)), y(e))) {
                  var r = l[t];
                  r ? A(e, r) : x(d, e),
                    L(e, n.classes.slide),
                    (i = e),
                    (o = u(a, "resize")),
                    (c = V(i, "img")),
                    (f = c.length)
                      ? c.forEach(function (e) {
                          s(e, "load error", function () {
                            --f || o();
                          });
                        })
                      : o();
                }
                var i, o, c, f;
              }),
                a("refresh");
            },
            remove: function (e) {
              U(
                C(e).map(function (e) {
                  return e.slide;
                })
              ),
                a("refresh");
            },
            forEach: _,
            filter: C,
            style: function (e, t, n) {
              _(function (r) {
                r.style(e, t, n);
              });
            },
            getLength: function (e) {
              return e ? l.length : f.length;
            },
            isEnough: function () {
              return f.length > n.perPage;
            },
          };
        },
        Layout: function (e, t, n) {
          var r,
            i,
            o = pe(e),
            a = o.on,
            s = o.bind,
            c = o.emit,
            l = t.Slides,
            d = t.Direction.resolve,
            p = t.Elements,
            v = p.root,
            m = p.track,
            h = p.list,
            g = l.getAt,
            y = l.style;
          function b() {
            (i = null),
              (r = "ttb" === n.direction),
              D(v, "maxWidth", $(n.width)),
              D(m, d("paddingLeft"), w(!1)),
              D(m, d("paddingRight"), w(!0)),
              S();
          }
          function S() {
            var e = W(v);
            (i && i.width === e.width && i.height === e.height) ||
              (D(
                m,
                "height",
                (function () {
                  var e = "";
                  r &&
                    (J((e = E()), "height or heightRatio is missing."),
                    (e = "calc(" + e + " - " + w(!1) + " - " + w(!0) + ")"));
                  return e;
                })()
              ),
              y(d("marginRight"), $(n.gap)),
              y(
                "width",
                n.autoWidth ? null : $(n.fixedWidth) || (r ? "" : _())
              ),
              y(
                "height",
                $(n.fixedHeight) || (r ? (n.autoHeight ? null : _()) : E()),
                !0
              ),
              (i = e),
              c("resized"));
          }
          function w(e) {
            var t = n.padding,
              r = d(e ? "right" : "left");
            return (t && $(t[r] || (f(t) ? 0 : t))) || "0px";
          }
          function E() {
            return $(n.height || W(h).width * n.heightRatio);
          }
          function _() {
            var e = $(n.gap);
            return (
              "calc((100%" +
              (e && " + " + e) +
              ")/" +
              (n.perPage || 1) +
              (e && " - " + e) +
              ")"
            );
          }
          function L(e, t) {
            var n = g(e);
            if (n) {
              var r = W(n.slide)[d("right")],
                i = W(h)[d("left")];
              return re(r - i) + (t ? 0 : x());
            }
            return 0;
          }
          function x() {
            var e = g(0);
            return (e && parseFloat(D(e.slide, d("marginRight")))) || 0;
          }
          return {
            mount: function () {
              var e, t, n;
              b(),
                s(
                  window,
                  "resize load",
                  ((e = u(c, "resize")),
                  function () {
                    n ||
                      (n = ve(
                        t || 0,
                        function () {
                          e(), (n = null);
                        },
                        null,
                        1
                      )).start();
                  })
                ),
                a(["updated", "refresh"], b),
                a("resize", S);
            },
            listSize: function () {
              return W(h)[d("width")];
            },
            slideSize: function (e, t) {
              var n = g(e || 0);
              return n ? W(n.slide)[d("width")] + (t ? 0 : x()) : 0;
            },
            sliderSize: function () {
              return L(e.length - 1, !0) - L(-1, !0);
            },
            totalSize: L,
            getPadding: function (e) {
              return (
                parseFloat(D(m, d("padding" + (e ? "Right" : "Left")))) || 0
              );
            },
          };
        },
        Clones: function (e, t, n) {
          var r,
            i = pe(e),
            a = i.on,
            u = i.emit,
            s = t.Elements,
            c = t.Slides,
            l = t.Direction.resolve,
            d = [];
          function f() {
            (r = m()) &&
              (!(function (t) {
                var r = c.get().slice(),
                  i = r.length;
                if (i) {
                  for (; r.length < t; ) E(r, r);
                  E(r.slice(-t), r.slice(0, t)).forEach(function (o, a) {
                    var u = a < t,
                      l = (function (t, r) {
                        var i = t.cloneNode(!0);
                        return (
                          L(i, n.classes.clone),
                          (i.id = e.root.id + "-clone" + ce(r + 1)),
                          i
                        );
                      })(o.slide, a);
                    u ? A(l, r[0].slide) : x(s.list, l),
                      E(d, l),
                      c.register(l, a - t + (u ? 0 : i), o.index);
                  });
                }
              })(r),
              u("resize"));
          }
          function p() {
            U(d), o(d);
          }
          function v() {
            r < m() && u("refresh");
          }
          function m() {
            var r = n.clones;
            if (e.is(Le)) {
              if (!r) {
                var i = n[l("fixedWidth")] && t.Layout.slideSize(0);
                r =
                  (i && ne(W(s.track)[l("width")] / i)) ||
                  (n[l("autoWidth")] && e.length) ||
                  2 * n.perPage;
              }
            } else r = 0;
            return r;
          }
          return {
            mount: function () {
              f(),
                a("refresh", p),
                a("refresh", f),
                a(["updated", "resize"], v);
            },
            destroy: p,
          };
        },
        Move: function (e, t, n) {
          var r,
            i = pe(e),
            o = i.on,
            a = i.emit,
            u = e.state.set,
            s = t.Layout,
            c = s.slideSize,
            l = s.getPadding,
            d = s.totalSize,
            f = s.listSize,
            p = s.sliderSize,
            v = t.Direction,
            m = v.resolve,
            g = v.orient,
            y = t.Elements,
            b = y.list,
            S = y.track;
          function w() {
            t.Controller.isBusy() ||
              (t.Scroll.cancel(), E(e.index), t.Slides.update());
          }
          function E(e) {
            _(k(e, !0));
          }
          function _(n, r) {
            if (!e.is("fade")) {
              var i = r
                ? n
                : (function (n) {
                    if (e.is(Le)) {
                      var r = A(n),
                        i = r > t.Controller.getEnd();
                      (r < 0 || i) && (n = L(n, i));
                    }
                    return n;
                  })(n);
              D(b, "transform", "translate" + m("X") + "(" + i + "px)"),
                n !== i && a("shifted");
            }
          }
          function L(e, t) {
            var n = e - M(t),
              r = p();
            return (e -= g(r * (ne(re(n) / r) || 1)) * (t ? 1 : -1));
          }
          function x() {
            _(C()), r.cancel();
          }
          function A(e) {
            for (
              var n = t.Slides.get(), r = 0, i = 1 / 0, o = 0;
              o < n.length;
              o++
            ) {
              var a = n[o].index,
                u = re(k(a, !0) - e);
              if (!(u <= i)) break;
              (i = u), (r = a);
            }
            return r;
          }
          function k(t, r) {
            var i = g(
              d(t - 1) -
                (function (e) {
                  var t = n.focus;
                  return "center" === t ? (f() - c(e, !0)) / 2 : +t * c(e) || 0;
                })(t)
            );
            return r
              ? (function (t) {
                  n.trimSpace && e.is("slide") && (t = ae(t, 0, g(p() - f())));
                  return t;
                })(i)
              : i;
          }
          function C() {
            var e = m("left");
            return W(b)[e] - W(S)[e] + g(l(!1));
          }
          function M(e) {
            return k(e ? t.Controller.getEnd() : 0, !!n.trimSpace);
          }
          return {
            mount: function () {
              (r = t.Transition),
                o(["mounted", "resized", "updated", "refresh"], w);
            },
            move: function (e, t, n, i) {
              var o, s;
              e !== t &&
                ((o = e > n),
                (s = g(L(C(), o))),
                o ? s >= 0 : s <= b[m("scrollWidth")] - W(S)[m("width")]) &&
                (x(), _(L(C(), e > n), !0)),
                u(4),
                a("move", t, n, e),
                r.start(t, function () {
                  u(3), a("moved", t, n, e), i && i();
                });
            },
            jump: E,
            translate: _,
            shift: L,
            cancel: x,
            toIndex: A,
            toPosition: k,
            getPosition: C,
            getLimit: M,
            exceededLimit: function (e, t) {
              t = h(t) ? C() : t;
              var n = !0 !== e && g(t) < g(M(!1)),
                r = !1 !== e && g(t) > g(M(!0));
              return n || r;
            },
            reposition: w,
          };
        },
        Controller: function (e, t, n) {
          var r,
            i,
            o,
            a = pe(e).on,
            s = t.Move,
            c = s.getPosition,
            l = s.getLimit,
            d = s.toPosition,
            f = t.Slides,
            p = f.isEnough,
            v = f.getLength,
            g = e.is(Le),
            y = e.is("slide"),
            b = u(L, !1),
            S = u(L, !0),
            w = n.start || 0,
            E = w;
          function _() {
            (r = v(!0)), (i = n.perMove), (o = n.perPage);
            var e = ae(w, 0, r - 1);
            e !== w && ((w = e), s.reposition());
          }
          function L(e, t) {
            var n = i || (q() ? 1 : o),
              r = x(w + n * (e ? -1 : 1), w, !(i || q()));
            return -1 === r && y && !ie(c(), l(!e), 1)
              ? e
                ? 0
                : k()
              : t
              ? r
              : A(r);
          }
          function x(t, a, u) {
            if (p() || q()) {
              var s = k(),
                l = (function (t) {
                  if (y && "move" === n.trimSpace && t !== w)
                    for (
                      var r = c();
                      r === d(t, !0) && oe(t, 0, e.length - 1, !n.rewind);

                    )
                      t < w ? --t : ++t;
                  return t;
                })(t);
              l !== t && ((a = t), (t = l), (u = !1)),
                t < 0 || t > s
                  ? (t =
                      i || (!oe(0, t, a, !0) && !oe(s, a, t, !0))
                        ? g
                          ? u
                            ? t < 0
                              ? -(r % o || o)
                              : r
                            : t
                          : n.rewind
                          ? t < 0
                            ? s
                            : 0
                          : -1
                        : C(M(t)))
                  : u && t !== a && (t = C(M(a) + (t < a ? -1 : 1)));
            } else t = -1;
            return t;
          }
          function A(e) {
            return g ? (e + r) % r || 0 : e;
          }
          function k() {
            return ee(r - (q() || (g && i) ? 1 : o), 0);
          }
          function C(e) {
            return ae(q() ? e : o * e, 0, k());
          }
          function M(e) {
            return q() ? e : te((e >= k() ? r - 1 : e) / o);
          }
          function P(e) {
            e !== w && ((E = w), (w = e));
          }
          function q() {
            return !h(n.focus) || n.isNavigation;
          }
          function T() {
            return e.state.is([4, 5]) && !!n.waitForTransition;
          }
          return {
            mount: function () {
              _(), a(["updated", "refresh"], _);
            },
            go: function (e, t, n) {
              if (!T()) {
                var r = (function (e) {
                    var t = w;
                    if (m(e)) {
                      var n = e.match(/([+\-<>])(\d+)?/) || [],
                        r = n[1],
                        i = n[2];
                      "+" === r || "-" === r
                        ? (t = x(w + +("" + r + (+i || 1)), w))
                        : ">" === r
                        ? (t = i ? C(+i) : b(!0))
                        : "<" === r && (t = S(!0));
                    } else t = g ? e : ae(e, 0, k());
                    return t;
                  })(e),
                  i = A(r);
                i > -1 && (t || i !== w) && (P(i), s.move(r, i, E, n));
              }
            },
            scroll: function (e, n, r, i) {
              t.Scroll.scroll(e, n, r, function () {
                P(A(s.toIndex(c()))), i && i();
              });
            },
            getNext: b,
            getPrev: S,
            getAdjacent: L,
            getEnd: k,
            setIndex: P,
            getIndex: function (e) {
              return e ? E : w;
            },
            toIndex: C,
            toPage: M,
            toDest: function (e) {
              var t = s.toIndex(e);
              return y ? ae(t, 0, k()) : t;
            },
            hasFocus: q,
            isBusy: T,
          };
        },
        Arrows: function (e, t, n) {
          var r,
            i,
            o = pe(e),
            a = o.on,
            s = o.bind,
            c = o.emit,
            l = n.classes,
            d = n.i18n,
            f = t.Elements,
            p = t.Controller,
            v = f.arrows,
            m = f.track,
            h = v,
            g = f.prev,
            y = f.next,
            b = {};
          function S() {
            !(function () {
              var e = n.arrows;
              !e ||
                (g && y) ||
                ((h = v || O("div", l.arrows)),
                (g = k(!0)),
                (y = k(!1)),
                (r = !0),
                x(h, [g, y]),
                !v && A(h, m));
              g &&
                y &&
                (T(b, {
                  prev: g,
                  next: y,
                }),
                N(h, e ? "" : "none"),
                L(h, (i = "splide__arrows--" + n.direction)),
                e &&
                  (a(["moved", "refresh", "scrolled"], C),
                  s(y, "click", u(_, ">")),
                  s(g, "click", u(_, "<")),
                  C(),
                  j([g, y], "aria-controls", m.id),
                  c("arrows:mounted", g, y)));
            })(),
              a("updated", w);
          }
          function w() {
            E(), S();
          }
          function E() {
            o.destroy(),
              Y(h, i),
              r ? (U(v ? [g, y] : h), (g = y = null)) : I([g, y], ye);
          }
          function _(e) {
            p.go(e, !0);
          }
          function k(e) {
            return B(
              '<button class="' +
                l.arrow +
                " " +
                (e ? l.prev : l.next) +
                '" type="button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" width="40" height="40" focusable="false"><path d="' +
                (n.arrowPath || Ae) +
                '" />'
            );
          }
          function C() {
            var t = e.index,
              n = p.getPrev(),
              r = p.getNext(),
              i = n > -1 && t < n ? d.last : d.prev,
              o = r > -1 && t > r ? d.first : d.next;
            (g.disabled = n < 0),
              (y.disabled = r < 0),
              j(g, "aria-label", i),
              j(y, "aria-label", o),
              c("arrows:updated", g, y, n, r);
          }
          return {
            arrows: b,
            mount: S,
            destroy: E,
            update: C,
          };
        },
        Autoplay: function (e, t, n) {
          var r,
            i,
            o = pe(e),
            a = o.on,
            u = o.bind,
            s = o.emit,
            c = ve(n.interval, e.go.bind(e, ">"), function (e) {
              var t = d.bar;
              t && D(t, "width", 100 * e + "%"), s("autoplay:playing", e);
            }),
            l = c.isPaused,
            d = t.Elements,
            f = t.Elements,
            p = f.root,
            v = f.toggle,
            m = n.autoplay,
            h = "pause" === m;
          function g() {
            l() &&
              t.Slides.isEnough() &&
              (c.start(!n.resetProgress),
              (i = r = h = !1),
              S(),
              s("autoplay:play"));
          }
          function y(e) {
            void 0 === e && (e = !0),
              (h = !!e),
              S(),
              l() || (c.pause(), s("autoplay:pause"));
          }
          function b() {
            h || (r || i ? y(!1) : g());
          }
          function S() {
            v &&
              (_(v, Se, !h), j(v, "aria-label", n.i18n[h ? "play" : "pause"]));
          }
          function w(e) {
            var r = t.Slides.getAt(e);
            c.set((r && +H(r.slide, "data-splide-interval")) || n.interval);
          }
          return {
            mount: function () {
              m &&
                (!(function () {
                  n.pauseOnHover &&
                    u(p, "mouseenter mouseleave", function (e) {
                      (r = "mouseenter" === e.type), b();
                    });
                  n.pauseOnFocus &&
                    u(p, "focusin focusout", function (e) {
                      (i = "focusin" === e.type), b();
                    });
                  v &&
                    u(v, "click", function () {
                      h ? g() : y(!0);
                    });
                  a(["move", "scroll", "refresh"], c.rewind), a("move", w);
                })(),
                v && j(v, "aria-controls", d.track.id),
                h || g(),
                S());
            },
            destroy: c.cancel,
            play: g,
            pause: y,
            isPaused: l,
          };
        },
        Cover: function (e, t, n) {
          var r = pe(e).on;
          function i(e) {
            t.Slides.forEach(function (t) {
              var n = M(t.container || t.slide, "img");
              n && n.src && o(e, n, t);
            });
          }
          function o(e, t, n) {
            n.style(
              "background",
              e ? 'center/cover no-repeat url("' + t.src + '")' : "",
              !0
            ),
              N(t, e ? "none" : "");
          }
          return {
            mount: function () {
              n.cover &&
                (r("lazyload:loaded", u(o, !0)),
                r(["mounted", "updated", "refresh"], u(i, !0)));
            },
            destroy: u(i, !1),
          };
        },
        Scroll: function (e, t, n) {
          var r,
            i,
            o = pe(e),
            a = o.on,
            s = o.emit,
            c = e.state.set,
            l = t.Move,
            d = l.getPosition,
            f = l.getLimit,
            p = l.exceededLimit,
            v = l.translate,
            m = e.is("slide"),
            h = 1;
          function g(e, n, o, a, f) {
            var v = d();
            if ((S(), o && (!m || !p()))) {
              var g = t.Layout.sliderSize(),
                w = ue(e) * g * te(re(e) / g) || 0;
              e = l.toPosition(t.Controller.toDest(e % g)) + w;
            }
            var E = ie(v, e, 1);
            (h = 1),
              (n = E ? 0 : n || ee(re(e - v) / 1.5, 800)),
              (i = a),
              (r = ve(n, y, u(b, v, e, f), 1)),
              c(5),
              s("scroll"),
              r.start();
          }
          function y() {
            c(3), i && i(), s("scrolled");
          }
          function b(e, t, r, o) {
            var a,
              u,
              s = d(),
              c =
                (e +
                  (t - e) *
                    ((a = o),
                    (u = n.easingFunc) ? u(a) : 1 - Math.pow(1 - a, 4)) -
                  s) *
                h;
            v(s + c),
              m &&
                !r &&
                p() &&
                ((h *= 0.6), re(c) < 10 && g(f(p(!0)), 600, !1, i, !0));
          }
          function S() {
            r && r.cancel();
          }
          function w() {
            r && !r.isPaused() && (S(), y());
          }
          return {
            mount: function () {
              a("move", S), a(["updated", "refresh"], w);
            },
            destroy: S,
            scroll: g,
            cancel: w,
          };
        },
        Drag: function (e, t, n) {
          var r,
            i,
            o,
            a,
            u,
            s,
            l,
            d,
            p = pe(e),
            v = p.on,
            m = p.emit,
            h = p.bind,
            g = p.unbind,
            y = e.state,
            b = t.Move,
            S = t.Scroll,
            w = t.Controller,
            E = t.Elements.track,
            _ = t.Media.reduce,
            L = t.Direction,
            x = L.resolve,
            A = L.orient,
            C = b.getPosition,
            M = b.exceededLimit,
            P = !1;
          function q() {
            var e = n.drag;
            Q(!e), (a = "free" === e);
          }
          function T(e) {
            if (((s = !1), !l)) {
              var t = H(e);
              (r = e.target),
                (i = n.noDrag),
                k(r, ".splide__pagination__page, .splide__arrow") ||
                  (i && k(r, i)) ||
                  (!t && e.button) ||
                  (w.isBusy()
                    ? G(e, !0)
                    : ((d = t ? E : window),
                      (u = y.is([4, 5])),
                      (o = null),
                      h(d, "touchmove mousemove", z, ke),
                      h(d, _e, F, ke),
                      b.cancel(),
                      S.cancel(),
                      j(e)));
            }
            var r, i;
          }
          function z(t) {
            if ((y.is(6) || (y.set(6), m("drag")), t.cancelable))
              if (u) {
                b.translate(r + O(t) / (P && e.is("slide") ? 5 : 1));
                var i = D(t) > 200,
                  o = P !== (P = M());
                (i || o) && j(t), (s = !0), m("dragging"), G(t);
              } else
                (function (e) {
                  return re(O(e)) > re(O(e, !0));
                })(t) &&
                  ((u = (function (e) {
                    var t = n.dragMinThreshold,
                      r = f(t),
                      i = (r && t.mouse) || 0,
                      o = (r ? t.touch : +t) || 10;
                    return re(O(e)) > (H(e) ? o : i);
                  })(t)),
                  G(t));
          }
          function F(r) {
            y.is(6) && (y.set(3), m("dragged")),
              u &&
                (!(function (r) {
                  var i = (function (t) {
                      if (e.is(Le) || !P) {
                        var n = D(t);
                        if (n && n < 200) return O(t) / n;
                      }
                      return 0;
                    })(r),
                    o = (function (e) {
                      return (
                        C() +
                        ue(e) *
                          Z(
                            re(e) * (n.flickPower || 600),
                            a
                              ? 1 / 0
                              : t.Layout.listSize() * (n.flickMaxPages || 1)
                          )
                      );
                    })(i),
                    u = n.rewind && n.rewindByDrag;
                  _(!1),
                    a
                      ? w.scroll(o, 0, n.snap)
                      : e.is("fade")
                      ? w.go(A(ue(i)) < 0 ? (u ? "<" : "-") : u ? ">" : "+")
                      : e.is("slide") && P && u
                      ? w.go(M(!0) ? ">" : "<")
                      : w.go(w.toDest(o), !0);
                  _(!0);
                })(r),
                G(r)),
              g(d, "touchmove mousemove", z),
              g(d, _e, F),
              (u = !1);
          }
          function I(e) {
            !l && s && G(e, !0);
          }
          function j(e) {
            (o = i), (i = e), (r = C());
          }
          function O(e, t) {
            return R(e, t) - R(N(e), t);
          }
          function D(e) {
            return K(e) - K(N(e));
          }
          function N(e) {
            return (i === e && o) || i;
          }
          function R(e, t) {
            return (H(e) ? e.changedTouches[0] : e)["page" + x(t ? "Y" : "X")];
          }
          function H(e) {
            return "undefined" != typeof TouchEvent && e instanceof TouchEvent;
          }
          function Q(e) {
            l = e;
          }
          return {
            mount: function () {
              h(E, "touchmove mousemove", c, ke),
                h(E, _e, c, ke),
                h(E, "touchstart mousedown", T, ke),
                h(E, "click", I, {
                  capture: !0,
                }),
                h(E, "dragstart", G),
                v(["mounted", "updated"], q);
            },
            disable: Q,
            isDragging: function () {
              return u;
            },
          };
        },
        Keyboard: function (e, t, n) {
          var r,
            i,
            o = pe(e),
            a = o.on,
            u = o.bind,
            c = o.unbind,
            l = e.root,
            d = t.Direction.resolve;
          function f() {
            var e = n.keyboard;
            e && ((r = "global" === e ? window : l), u(r, "keydown", m));
          }
          function p() {
            c(r, "keydown");
          }
          function v() {
            var e = i;
            (i = !0),
              s(function () {
                i = e;
              });
          }
          function m(t) {
            if (!i) {
              var n = Me(t);
              n === d("ArrowLeft")
                ? e.go("<")
                : n === d("ArrowRight") && e.go(">");
            }
          }
          return {
            mount: function () {
              f(), a("updated", p), a("updated", f), a("move", v);
            },
            destroy: p,
            disable: function (e) {
              i = e;
            },
          };
        },
        LazyLoad: function (e, t, n) {
          var r = pe(e),
            i = r.on,
            a = r.off,
            s = r.bind,
            c = r.emit,
            l = "sequential" === n.lazyLoad,
            d = ["moved", "scrolled"],
            f = [];
          function p() {
            o(f),
              t.Slides.forEach(function (e) {
                V(
                  e.slide,
                  "[data-splide-lazy], [data-splide-lazy-srcset]"
                ).forEach(function (t) {
                  var r = H(t, "data-splide-lazy"),
                    i = H(t, "data-splide-lazy-srcset");
                  if (r !== t.src || i !== t.srcset) {
                    var o = n.classes.spinner,
                      a = t.parentElement,
                      u = M(a, "." + o) || O("span", o, a);
                    f.push([t, e, u]), t.src || N(t, "none");
                  }
                });
              }),
              l ? g() : (a(d), i(d, v), v());
          }
          function v() {
            (f = f.filter(function (t) {
              var r = n.perPage * ((n.preloadPages || 1) + 1) - 1;
              return !t[1].isWithin(e.index, r) || m(t);
            })).length || a(d);
          }
          function m(e) {
            var t = e[0];
            L(e[1].slide, "is-loading"),
              s(t, "load error", u(h, e)),
              j(t, "src", H(t, "data-splide-lazy")),
              j(t, "srcset", H(t, "data-splide-lazy-srcset")),
              I(t, "data-splide-lazy"),
              I(t, "data-splide-lazy-srcset");
          }
          function h(e, t) {
            var n = e[0],
              r = e[1];
            Y(r.slide, "is-loading"),
              "error" !== t.type &&
                (U(e[2]), N(n, ""), c("lazyload:loaded", n, r), c("resize")),
              l && g();
          }
          function g() {
            f.length && m(f.shift());
          }
          return {
            mount: function () {
              n.lazyLoad && (p(), i("refresh", p));
            },
            destroy: u(o, f),
            check: v,
          };
        },
        Pagination: function (e, t, n) {
          var r,
            i,
            s = pe(e),
            c = s.on,
            l = s.emit,
            d = s.bind,
            f = t.Slides,
            p = t.Elements,
            v = t.Controller,
            m = v.hasFocus,
            h = v.getIndex,
            g = v.go,
            y = t.Direction.resolve,
            b = p.pagination,
            S = [];
          function w() {
            r && (U(b ? a(r.children) : r), Y(r, i), o(S), (r = null)),
              s.destroy();
          }
          function E(e) {
            g(">" + e, !0);
          }
          function _(e, t) {
            var n = S.length,
              r = Me(t),
              i = x(),
              o = -1;
            r === y("ArrowRight", !1, i)
              ? (o = ++e % n)
              : r === y("ArrowLeft", !1, i)
              ? (o = (--e + n) % n)
              : "Home" === r
              ? (o = 0)
              : "End" === r && (o = n - 1);
            var a = S[o];
            a && (R(a.button), g(">" + o), G(t, !0));
          }
          function x() {
            return n.paginationDirection || n.direction;
          }
          function A(e) {
            return S[v.toPage(e)];
          }
          function k() {
            var e = A(h(!0)),
              t = A(h());
            if (e) {
              var n = e.button;
              Y(n, Se), I(n, "aria-selected"), j(n, "tabindex", -1);
            }
            if (t) {
              var i = t.button;
              L(i, Se), j(i, "aria-selected", !0), j(i, "tabindex", "");
            }
            l(
              "pagination:updated",
              {
                list: r,
                items: S,
              },
              e,
              t
            );
          }
          return {
            items: S,
            mount: function t() {
              w(), c(["updated", "refresh"], t);
              var o = n.pagination && f.isEnough();
              b && N(b, o ? "" : "none"),
                o &&
                  (c(["move", "scroll", "scrolled"], k),
                  (function () {
                    var t = e.length,
                      o = n.classes,
                      a = n.i18n,
                      s = n.perPage,
                      c = m() ? t : ne(t / s);
                    L(
                      (r = b || O("ul", o.pagination, p.track.parentElement)),
                      (i = "splide__pagination--" + x())
                    ),
                      j(r, ge, "tablist"),
                      j(r, "aria-label", a.select),
                      j(r, "aria-orientation", "ttb" === x() ? "vertical" : "");
                    for (var l = 0; l < c; l++) {
                      var v = O("li", null, r),
                        h = O(
                          "button",
                          {
                            class: o.page,
                            type: "button",
                          },
                          v
                        ),
                        g = f.getIn(l).map(function (e) {
                          return e.slide.id;
                        }),
                        y = !m() && s > 1 ? a.pageX : a.slideX;
                      d(h, "click", u(E, l)),
                        n.paginationKeyboard && d(h, "keydown", u(_, l)),
                        j(v, ge, "presentation"),
                        j(h, ge, "tab"),
                        j(h, "aria-controls", g.join(" ")),
                        j(h, "aria-label", se(y, l + 1)),
                        j(h, "tabindex", -1),
                        S.push({
                          li: v,
                          button: h,
                          page: l,
                        });
                    }
                  })(),
                  k(),
                  l(
                    "pagination:mounted",
                    {
                      list: r,
                      items: S,
                    },
                    A(e.index)
                  ));
            },
            destroy: w,
            getAt: A,
            update: k,
          };
        },
        Sync: function (e, t, n) {
          var r = n.isNavigation,
            i = n.slideFocus,
            a = [];
          function u() {
            var t, n;
            e.splides.forEach(function (t) {
              t.isParent || (c(e, t.splide), c(t.splide, e));
            }),
              r &&
                ((t = pe(e)),
                (n = t.on)("click", d),
                n("slide:keydown", f),
                n(["mounted", "updated"], l),
                a.push(t),
                t.emit("navigation:mounted", e.splides));
          }
          function s() {
            a.forEach(function (e) {
              e.destroy();
            }),
              o(a);
          }
          function c(e, t) {
            var n = pe(e);
            n.on("move", function (e, n, r) {
              t.go(t.is(Le) ? r : e);
            }),
              a.push(n);
          }
          function l() {
            j(
              t.Elements.list,
              "aria-orientation",
              "ttb" === n.direction ? "vertical" : ""
            );
          }
          function d(t) {
            e.go(t.index);
          }
          function f(e, t) {
            w(Pe, Me(t)) && (d(e), G(t));
          }
          return {
            setup: function () {
              e.options = {
                slideFocus: h(i) ? r : i,
              };
            },
            mount: u,
            destroy: s,
            remount: function () {
              s(), u();
            },
          };
        },
        Wheel: function (e, t, n) {
          var r = pe(e).bind,
            i = 0;
          function o(r) {
            if (r.cancelable) {
              var o = r.deltaY,
                a = o < 0,
                u = K(r),
                s = n.wheelMinThreshold || 0,
                c = n.wheelSleep || 0;
              re(o) > s && u - i > c && (e.go(a ? "<" : ">"), (i = u)),
                (function (r) {
                  return (
                    !n.releaseWheel ||
                    e.state.is(4) ||
                    -1 !== t.Controller.getAdjacent(r)
                  );
                })(a) && G(r);
            }
          }
          return {
            mount: function () {
              n.wheel && r(t.Elements.track, "wheel", o, ke);
            },
          };
        },
        Live: function (e, t, n) {
          var r = pe(e).on,
            i = t.Elements.track,
            o = n.live && !n.isNavigation,
            a = O("span", "splide__sr"),
            s = ve(90, u(c, !1));
          function c(e) {
            j(i, "aria-busy", e), e ? (x(i, a), s.start()) : U(a);
          }
          function l(e) {
            o && j(i, "aria-live", e ? "off" : "polite");
          }
          return {
            mount: function () {
              o &&
                (l(!t.Autoplay.isPaused()),
                j(i, "aria-atomic", !0),
                (a.textContent = "…"),
                r("autoplay:play", u(l, !0)),
                r("autoplay:pause", u(l, !1)),
                r(["moved", "scrolled"], u(c, !0)));
            },
            disable: l,
            destroy: function () {
              I(i, ["aria-live", "aria-atomic", "aria-busy"]), U(a);
            },
          };
        },
      }),
      Te = {
        type: "slide",
        role: "region",
        speed: 400,
        perPage: 1,
        cloneStatus: !0,
        arrows: !0,
        pagination: !0,
        paginationKeyboard: !0,
        interval: 5e3,
        pauseOnHover: !0,
        pauseOnFocus: !0,
        resetProgress: !0,
        easing: "cubic-bezier(0.25, 1, 0.5, 1)",
        drag: !0,
        direction: "ltr",
        trimSpace: !0,
        focusableNodes: "a, button, textarea, input, select, iframe",
        live: !0,
        classes: Ee,
        i18n: {
          prev: "Previous slide",
          next: "Next slide",
          first: "Go to first slide",
          last: "Go to last slide",
          slideX: "Go to slide %s",
          pageX: "Go to page %s",
          play: "Start autoplay",
          pause: "Pause autoplay",
          carousel: "carousel",
          slide: "slide",
          select: "Select a slide to show",
          slideLabel: "%s of %s",
        },
        reducedMotion: {
          speed: 0,
          rewindSpeed: 0,
          autoplay: "pause",
        },
      };
    function ze(e, t, n) {
      var r = pe(e).on;
      return {
        mount: function () {
          r(["mounted", "refresh"], function () {
            s(function () {
              t.Slides.style(
                "transition",
                "opacity " + n.speed + "ms " + n.easing
              );
            });
          });
        },
        start: function (e, n) {
          var r = t.Elements.track;
          D(r, "height", $(W(r).height)),
            s(function () {
              n(), D(r, "height", "");
            });
        },
        cancel: c,
      };
    }
    function Fe(e, t, n) {
      var r,
        i = pe(e).bind,
        o = t.Move,
        a = t.Controller,
        s = t.Scroll,
        c = t.Elements.list,
        l = u(D, c, "transition");
      function d() {
        l(""), s.cancel();
      }
      return {
        mount: function () {
          i(c, "transitionend", function (e) {
            e.target === c && r && (d(), r());
          });
        },
        start: function (t, i) {
          var u = o.toPosition(t, !0),
            c = o.getPosition(),
            d = (function (t) {
              var r = n.rewindSpeed;
              if (e.is("slide") && r) {
                var i = a.getIndex(!0),
                  o = a.getEnd();
                if ((0 === i && t >= o) || (i >= o && 0 === t)) return r;
              }
              return n.speed;
            })(t);
          re(u - c) >= 1 && d >= 1
            ? n.useScroll
              ? s.scroll(u, d, !1, i)
              : (l("transform " + d + "ms " + n.easing),
                o.translate(u, !0),
                (r = i))
            : (o.jump(t), i());
        },
        cancel: d,
      };
    }
    var Ie = (function () {
      function e(t, n) {
        var r;
        (this.event = pe()),
          (this.Components = {}),
          (this.state =
            ((r = 1),
            {
              set: function (e) {
                r = e;
              },
              is: function (e) {
                return w(b(e), r);
              },
            })),
          (this.splides = []),
          (this._o = {}),
          (this._E = {});
        var i = m(t) ? X(document, t) : t;
        J(i, i + " is invalid."),
          (this.root = i),
          (n = z(
            {
              label: H(i, "aria-label") || "",
              labelledby: H(i, "aria-labelledby") || "",
            },
            Te,
            e.defaults,
            n || {}
          ));
        try {
          z(n, JSON.parse(H(i, "data-splide")));
        } catch (e) {
          J(!1, "Invalid JSON");
        }
        this._o = Object.create(z({}, n));
      }
      var t,
        n,
        i,
        u = e.prototype;
      return (
        (u.mount = function (e, t) {
          var n = this,
            r = this.state,
            i = this.Components;
          return (
            J(r.is([1, 7]), "Already mounted!"),
            r.set(1),
            (this._C = i),
            (this._T = t || this._T || (this.is("fade") ? ze : Fe)),
            (this._E = e || this._E),
            q(
              T({}, qe, this._E, {
                Transition: this._T,
              }),
              function (e, t) {
                var r = e(n, i, n._o);
                (i[t] = r), r.setup && r.setup();
              }
            ),
            q(i, function (e) {
              e.mount && e.mount();
            }),
            this.emit("mounted"),
            L(this.root, "is-initialized"),
            r.set(3),
            this.emit("ready"),
            this
          );
        }),
        (u.sync = function (e) {
          return (
            this.splides.push({
              splide: e,
            }),
            e.splides.push({
              splide: this,
              isParent: !0,
            }),
            this.state.is(3) &&
              (this._C.Sync.remount(), e.Components.Sync.remount()),
            this
          );
        }),
        (u.go = function (e) {
          return this._C.Controller.go(e), this;
        }),
        (u.on = function (e, t) {
          return this.event.on(e, t), this;
        }),
        (u.off = function (e) {
          return this.event.off(e), this;
        }),
        (u.emit = function (e) {
          var t;
          return (
            (t = this.event).emit.apply(t, [e].concat(a(arguments, 1))), this
          );
        }),
        (u.add = function (e, t) {
          return this._C.Slides.add(e, t), this;
        }),
        (u.remove = function (e) {
          return this._C.Slides.remove(e), this;
        }),
        (u.is = function (e) {
          return this._o.type === e;
        }),
        (u.refresh = function () {
          return this.emit("refresh"), this;
        }),
        (u.destroy = function (e) {
          void 0 === e && (e = !0);
          var t = this.event,
            n = this.state;
          return (
            n.is(1)
              ? pe(this).on("ready", this.destroy.bind(this, e))
              : (q(
                  this._C,
                  function (t) {
                    t.destroy && t.destroy(e);
                  },
                  !0
                ),
                t.emit("destroy"),
                t.destroy(),
                e && o(this.splides),
                n.set(7)),
            this
          );
        }),
        (t = e),
        (n = [
          {
            key: "options",
            get: function () {
              return this._o;
            },
            set: function (e) {
              this._C.Media.set(e, !0);
            },
          },
          {
            key: "length",
            get: function () {
              return this._C.Slides.getLength(!0);
            },
          },
          {
            key: "index",
            get: function () {
              return this._C.Controller.getIndex();
            },
          },
        ]) && r(t.prototype, n),
        i && r(t, i),
        Object.defineProperty(t, "prototype", {
          writable: !1,
        }),
        e
      );
    })();
    (Ie.defaults = {}), (Ie.STATES = i);
    n(1), n(2), n(3), n(4), n(5);
    function je(e, t) {
      var n =
        ("undefined" != typeof Symbol && e[Symbol.iterator]) || e["@@iterator"];
      if (!n) {
        if (
          Array.isArray(e) ||
          (n = (function (e, t) {
            if (!e) return;
            if ("string" == typeof e) return Oe(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if (
              "Arguments" === n ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
            )
              return Oe(e, t);
          })(e)) ||
          (t && e && "number" == typeof e.length)
        ) {
          n && (e = n);
          var r = 0,
            i = function () {};
          return {
            s: i,
            n: function () {
              return r >= e.length
                ? {
                    done: !0,
                  }
                : {
                    done: !1,
                    value: e[r++],
                  };
            },
            e: function (e) {
              throw e;
            },
            f: i,
          };
        }
        throw new TypeError(
          "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      }
      var o,
        a = !0,
        u = !1;
      return {
        s: function () {
          n = n.call(e);
        },
        n: function () {
          var e = n.next();
          return (a = e.done), e;
        },
        e: function (e) {
          (u = !0), (o = e);
        },
        f: function () {
          try {
            a || null == n.return || n.return();
          } finally {
            if (u) throw o;
          }
        },
      };
    }
    function Oe(e, t) {
      (null == t || t > e.length) && (t = e.length);
      for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    var De,
      Ne = document.getElementById("alert-message"),
      Re = document.querySelectorAll(".saveBtn"),
      He = document.querySelector(".steppers-nav"),
      Qe = !1,
      We = (function () {
        if ("speechSynthesis" in window || speechSynthesis) {
          var e = window.speechSynthesis || speechSynthesis,
            t = new SpeechSynthesisUtterance();
          (t.voiceURI = "native"),
            (t.volume = 1),
            (t.rate = 0.8),
            (t.pitch = 1),
            (t.lang = "it-IT");
          var n = function () {
            var n = [];
            (n = e.getVoices()),
              (t.voice = n.find(function (e) {
                return "it-IT" === e.lang;
              }, "Paulina"));
          };
          return (
            n(),
            void 0 !== e.onvoiceschanged && (e.onvoiceschanged = n),
            {
              T2S: e,
              message: t,
            }
          );
        }
      })(),
      Ue = We.T2S,
      Be = We.message,
      Ge = function () {
        (De.children[1].innerText = "Ascolta"), (Qe = !1), Ue.cancel();
      };
    Be.addEventListener("end", function () {
      Ge();
    });
    var Xe;
    (window.listenElements = function (e, t) {
      if (((De = e), !0 !== Qe)) {
        var n,
          r,
          i,
          o = "",
          a = je(document.querySelectorAll(t));
        try {
          for (a.s(); !(n = a.n()).done; ) {
            var u = n.value;
            o =
              o +
              ((r = u.innerHTML),
              (i = void 0),
              ((i = document.createElement("div")).innerHTML = r),
              i.textContent || i.innerText || "") +
              " ";
          }
        } catch (e) {
          a.e(e);
        } finally {
          a.f();
        }
        !(function (e) {
          (De.children[1].innerText = "Ferma audio"),
            (Qe = !0),
            (Be.text = e),
            Ue.cancel(),
            Ue.speak(Be),
            (window.onbeforeunload = function () {
              Ue.cancel();
            });
        })(o);
      } else Ge();
    }),
      document.addEventListener("DOMContentLoaded", function () {
        setTimeout(function () {
          !(function () {
            var e = document.querySelector(".carousel-4-card");
            if (!e) return;
            new Ie(e, {
              pagination: !1,
              arrows: !1,
              gap: "1rem",
              perPage: 4,
              perMove: 1,
              speed: 800,
              breakpoints: {
                1200: {
                  perPage: 3,
                  pagination: !0,
                },
                992: {
                  perPage: 2,
                  gap: "1rem",
                },
                768: {
                  perPage: 1,
                  gap: 0,
                },
              },
            }).mount();
          })();
        }, 400),
          Re.forEach(function (e) {
            e.addEventListener("click", function () {
              Ne.classList.remove("d-none"),
                He.classList.add("pb-4"),
                setTimeout(function () {
                  Ne.classList.add("d-none"), He.classList.remove("pb-4");
                }, 3e3);
            });
          });
      }),
      (Xe = document.querySelector("#errorMsgContainer")),
      document.querySelector("#justValidateForm") &&
        new bootstrap.FormValidate("#justValidateForm", {
          errorFieldCssClass: "is-invalid",
          errorLabelCssClass: "form-feedback",
          errorLabelStyle: "",
          focusInvalidField: !1,
        })
          .addField(".form-control", [
            {
              rule: "required",
              errorMessage: "Questo campo è richiesto",
            },
          ])
          .addField("#surname", [
            {
              rule: "required",
              errorMessage: "Questo campo è richiesto",
            },
          ])
          .addField("#email", [
            {
              rule: "required",
              errorMessage: "Questo campo è richiesto",
            },
            {
              rule: "email",
              errorMessage: "Email non valida",
            },
          ])
          .addField("#category", [
            {
              rule: "required",
              errorMessage: "Questo campo è richiesto",
            },
          ])
          .addField("#service", [
            {
              rule: "required",
              errorMessage: "Questo campo è richiesto",
            },
          ])
          .addField("#description", [
            {
              rule: "required",
              errorMessage: "Questo campo è richiesto",
            },
            {
              rule: "maxLength",
              value: 600,
              errorMessage:
                "Questo campo può contenere un massimo di 600 caratteri",
            },
          ])
          .addField("#privacy", [
            {
              rule: "required",
              errorMessage: "Questo campo è richiesto",
            },
          ])
          .onFail(function (e) {
            Xe && ((Xe.innerHTML = ""), (Xe.innerHTML = errorMessage));
          }),
      (function () {
        var e = document.querySelector("#errorMsgContainer");
        document.querySelector("#justValidateMulta") &&
          new bootstrap.FormValidate("#justValidateMulta", {
            errorFieldCssClass: "is-invalid",
            errorLabelCssClass: "form-feedback",
            errorLabelStyle: "",
            focusInvalidField: !1,
          })
            .addField("#code", [
              {
                rule: "required",
                errorMessage: "Questo campo è richiesto",
              },
            ])
            .addField("#date-1", [
              {
                rule: "required",
                errorMessage: "Questo campo è richiesto",
              },
            ])
            .onFail(function (t) {
              e && ((e.innerHTML = ""), (e.innerHTML = errorMessage));
            });
      })();
    var Ve = document.querySelector(".custom-navbar-toggler"),
      Ye = document.querySelector(".close-menu");
    Ve.addEventListener("click", function () {
      Ve.setAttribute("aria-expanded", "true");
    }),
      Ye.addEventListener("click", function () {
        Ve.setAttribute("aria-expanded", "false");
      });
  },
]);
